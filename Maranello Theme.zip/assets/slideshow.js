if (!customElements.get("slideshow-component")) {
  customElements.define(
    "slideshow-component",
    class SlideshowComponent extends HTMLElement {
      constructor() {
        super();
        this.slideshow = this.querySelector(".slideshow");
        this.progressBar = this.querySelector(".slideshow-progress-bar .progress-bar");
        this.start = null;
        this.progressBarWidth = 0;
        this.paused = false;
        this.isTransitioning = false;
        this.contentAnimationDelay = 400;
        this.contentExitDelay = 300;
        this.startProgressBar = this.startProgressBar.bind(this);
        this.animateProgressBar = this.animateProgressBar.bind(this);
        this.resetProgressBar = this.resetProgressBar.bind(this);

        // Create a promise that resolves when Flickity is ready
        this.flickityReady = new Promise((resolve) => {
          this._resolveFlickityReady = resolve;
        });
      }

      connectedCallback() {
        const autoplayEnabled = this.getAttribute("data-autoplay") === "true";
        this.autoPlaySpeed = parseInt(this.getAttribute("data-speed"), 10) * 1000;
        this.autoPlayEnabled = autoplayEnabled && this.autoPlaySpeed > 0 && !Shopify.designMode;
        this.animationType = this.getAttribute("data-animation-type") ?? "slide";
        this.paused = !this.autoPlayEnabled;

        if (!this.slideshow) {
          return;
        }

        this.slideshow.style.display = "block";
        this.initializeContentStates();

        // Performance: Use IntersectionObserver to delay initialization if slideshow is below fold
        if ("IntersectionObserver" in window && this.shouldDeferInitialization()) {
          const rect = this.getBoundingClientRect();
          const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
          if (rect.top < viewportHeight && rect.bottom > 0) {
            this.initializeFlickity();
          } else {
            this.deferredInit();
          }
          return;
        }

        this.initializeFlickity();
      }

      shouldDeferInitialization() {
        const rect = this.getBoundingClientRect();
        const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
        // If slideshow is more than 1.5 viewports below, defer initialization
        return rect.top > viewportHeight * 1.5;
      }

      deferredInit() {
        const observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                this.initializeFlickity();
                observer.unobserve(this);
              }
            });
          },
          {
            rootMargin: "500px", // Start loading when within 500px of viewport
          },
        );
        observer.observe(this);
      }

      initializeFlickity() {
        this.flickity = new Flickity(this.slideshow, {
          cellAlign: "left",
          percentPosition: true,
          fullscreen: true,
          contain: true,
          resize: true,
          draggable: true,
          prevNextButtons: false,
          fade: this.animationType === "fade",
          cellSelector: ".slideshow-slide",
          initialIndex: 0,
          pageDots: false,
          wrapAround: true,
          accessibility: false,
          on: {
            ready: () => {
              this.showSlideContent(0);

              // Wait a tick for custom elements to be fully defined
              setTimeout(() => {
                // Play first slide video if it exists
                this.playSlideVideo(0);
              }, 50);

              if (this.autoPlayEnabled) {
                this.startProgressBar();
              }

              setTimeout(() => {
                this.preloadSlide(1);
              }, 3000);
            },
            change: (index) => {
              this.handleSlideChange(index);
            },
          },
        });

        if (this.autoPlayEnabled) {
          this.slideshow.addEventListener("mouseenter", () => {
            this.paused = true;
            // Pause current video when user hovers
            this.pauseAllVideos();
          });

          this.slideshow.addEventListener("mouseleave", () => {
            this.paused = false;
            this.start = performance.now() - (this.progressBarWidth / 100) * this.autoPlaySpeed;
            window.requestAnimationFrame(this.animateProgressBar.bind(this));
            // Resume current video when hover ends
            if (this.flickity && typeof this.flickity.selectedIndex !== "undefined") {
              this.playSlideVideo(this.flickity.selectedIndex);
            }
          });
        }

        this.flickity.on("change", (index) => {
          publish(PUB_SUB_EVENTS.slideshowSlideChange, {
            id: this.getAttribute("id"),
            index,
          });
        });

        // Resolve the flickity ready promise
        this._resolveFlickityReady();
      }

      disconnectedCallback() {
        // Cleanup videos
        this.pauseAllVideos();
      }

      initializeContentStates() {
        const allContent = this.querySelectorAll(".slideshow-content-wrap");
        allContent.forEach((content, index) => {
          content.classList.remove("content-visible", "content-exit");
          content.classList.add("content-enter");
        });
      }

      resetAllContentStates() {
        const allContent = this.querySelectorAll(".slideshow-content-wrap");
        allContent.forEach((content) => {
          content.classList.remove("content-visible", "content-exit");
          content.classList.add("content-enter");
        });
      }

      showSlideContent(index) {
        this.resetAllContentStates();

        const slide = this.querySelectorAll(".slideshow-slide")[index];
        if (slide) {
          const content = slide.querySelector(".slideshow-content-wrap");
          if (content) {
            setTimeout(() => {
              content.classList.remove("content-enter", "content-exit");
              content.classList.add("content-visible");
            }, this.contentAnimationDelay);
          }
        }
      }

      hideSlideContent(index) {
        const slide = this.querySelectorAll(".slideshow-slide")[index];
        if (slide) {
          const content = slide.querySelector(".slideshow-content-wrap");
          if (content) {
            content.classList.remove("content-visible");
            content.classList.add("content-exit");
          }
        }
      }

      hideCurrentSlideContent() {
        if (this.flickity && typeof this.flickity.selectedIndex !== "undefined") {
          this.hideSlideContent(this.flickity.selectedIndex);
        }
      }

      handleSlideChange(index) {
        // Pause all videos first (performance optimization)
        this.pauseAllVideos();

        this.preloadSlide(index + 1);
        this.showSlideContent(index);

        // Play video for current slide
        this.playSlideVideo(index);

        if (this.autoPlayEnabled) {
          this.resetProgressBar();
          this.startProgressBar();
        }
      }

      transitionToNext() {
        if (this.isTransitioning || !this.flickity) {
          return;
        }

        this.isTransitioning = true;

        this.hideCurrentSlideContent();

        setTimeout(() => {
          this.flickity.next();
          this.isTransitioning = false;
        }, this.contentExitDelay);
      }

      transitionToPrev() {
        if (this.isTransitioning || !this.flickity) {
          return;
        }

        this.isTransitioning = true;

        this.hideCurrentSlideContent();

        setTimeout(() => {
          this.flickity.previous();
          this.isTransitioning = false;
        }, this.contentExitDelay);
      }

      goToSlide(index) {
        if (this.isTransitioning || !this.flickity) {
          return;
        }

        this.isTransitioning = true;
        this.hideCurrentSlideContent();

        setTimeout(() => {
          this.flickity.select(index);
          this.isTransitioning = false;
        }, this.contentExitDelay);
      }

      preloadSlide(index) {
        const slide = this.querySelectorAll(".slideshow-slide")[index];

        if (slide) {
          const media = slide.querySelector(".slideshow-media");
          media.style.display = "block";

          const images = slide.querySelectorAll("img");
          [...images].forEach((image) => {
            image.removeAttribute("loading");
          });

          // Performance: Preload video sources for next slide
          const video = this.getSlideVideo(index);
          if (video && !video.videoLoaded && typeof video.loadSources === "function") {
            video.loadSources();
          }
        }
      }

      getSlideVideo(index) {
        const slides = this.querySelectorAll(".slideshow-slide");
        const slide = slides[index];
        if (!slide) {
          return null;
        }
        return slide.querySelector("slideshow-video");
      }

      playSlideVideo(index) {
        const video = this.getSlideVideo(index);
        if (!video) {
          return;
        }

        // Check if video is disabled on mobile
        if (
          window.innerWidth < 750 &&
          video.classList.contains("slideshow-video-mobile-disabled")
        ) {
          return;
        }

        // Check if methods exist (custom element is defined)
        if (typeof video.play !== "function") {
          return;
        }

        video.play();
      }

      pauseAllVideos() {
        const allVideos = this.querySelectorAll("slideshow-video");
        allVideos.forEach((video) => {
          if (video && video.isPlaying && typeof video.pause === "function") {
            video.pause();
          }
        });
      }

      pauseVideoAtIndex(index) {
        const video = this.getSlideVideo(index);
        if (video && video.isPlaying && typeof video.pause === "function") {
          video.pause();
        }
      }

      startProgressBar() {
        this.paused = false;
        this.start = performance.now();
        this.animationFrame = window.requestAnimationFrame(this.animateProgressBar);
      }

      stopProgressBar() {
        if (this.animationFrame) {
          window.cancelAnimationFrame(this.animationFrame);
        }
      }

      resetProgressBar() {
        this.progressBarWidth = 0;
        this.progressBar.style.width = "0";
        this.start = performance.now();
      }

      animateProgressBar(currentTime) {
        if (this.paused) {
          return;
        }

        const elapsed = currentTime - this.start;
        const progress = elapsed / this.autoPlaySpeed;
        this.progressBarWidth = Math.min(progress * 100, 100);
        this.progressBar.style.width = `${this.progressBarWidth}%`;

        if (this.progressBarWidth >= 100) {
          this.stopProgressBar();
          this.transitionToNext();
        } else {
          this.animationFrame = window.requestAnimationFrame(this.animateProgressBar);
        }
      }
    },
  );
}

if (!customElements.get("slideshow-block-navigation-item")) {
  customElements.define(
    "slideshow-block-navigation-item",
    class SlideshowBlockNavigationItem extends HTMLElement {
      constructor() {
        super();
        this.slideshow = this.closest("slideshow-component");
        this.progressBar = this.querySelector(".progress");
        this.requestId = null;
        this.startProgressBar = this.startProgressBar.bind(this);
        this.stopProgressBar = this.stopProgressBar.bind(this);
        this.addEventListener("mouseover", (event) => {
          const index = Array.from(this.parentElement.children).indexOf(this);
          this.preloadSlide(index);
        });
      }

      startProgressBar() {
        this.progressBar.style.width = `${this.slideshow.progressBarWidth}%`;
        this.requestId = window.requestAnimationFrame(this.startProgressBar);
      }

      stopProgressBar() {
        if (this.requestId) {
          window.cancelAnimationFrame(this.requestId);
        }
      }

      preloadSlide(index) {
        this.slideshow.preloadSlide(index);
      }
    },
  );
}

if (!customElements.get("slideshow-block-navigation")) {
  customElements.define(
    "slideshow-block-navigation",
    class SlideshowBlockNavigation extends HTMLElement {
      constructor() {
        super();
        this.slideshow = this.closest("slideshow-component");
        this.scroller = this.querySelector(".slideshow-block-navigation-items");
        this.autoPlayEnabled = this.slideshow.autoPlayEnabled;
      }

      async connectedCallback() {
        // Wait for flickity to be ready
        await this.slideshow.flickityReady;
        this.flickity = this.slideshow.flickity;
        const navs = this.querySelectorAll(".slideshow-block-navigation-item");
        const initialNav = navs[this.flickity.selectedIndex];

        if (this.autoPlayEnabled) {
          initialNav.closest("slideshow-block-navigation-item")?.startProgressBar();
        }

        this.flickity.on("select", () => {
          navs.forEach((nav) => {
            nav.classList.remove("is-active");

            if (this.autoPlayEnabled) {
              nav.closest("slideshow-block-navigation-item")?.stopProgressBar();
            }
          });

          const activeNav = navs[this.flickity.selectedIndex];

          activeNav.classList.add("is-active");
          scrollIntoView({
            element: activeNav,
            container: this.scroller,
          });

          if (this.autoPlayEnabled) {
            activeNav.closest("slideshow-block-navigation-item")?.startProgressBar();
          }
        });

        navs.forEach((nav) => {
          nav.addEventListener("click", (event) => {
            event.preventDefault();
            const index = [...navs].findIndex((x) => x === nav);
            this.slideshow.goToSlide(index);
          });
        });
      }
    },
  );
}

if (!customElements.get("slideshow-navigation")) {
  customElements.define(
    "slideshow-navigation",
    class SlideshowNavigation extends HTMLElement {
      constructor() {
        super();
        this.slideshow = this.closest("slideshow-component");
      }

      async connectedCallback() {
        // Wait for flickity to be ready
        await this.slideshow.flickityReady;
        this.flickity = this.slideshow.flickity;

        // Pagination
        const buttons = this.querySelectorAll(".js-page");

        if (buttons.length) {
          this.flickity.on("select", () => {
            buttons.forEach((button) => {
              button.classList.remove("is-active");
            });

            buttons[this.flickity.selectedIndex].classList.add("is-active");
          });

          buttons.forEach((button) => {
            button.addEventListener("click", () => {
              const index = [...buttons].findIndex((x) => x === button);
              this.slideshow.goToSlide(index);
            });
          });
        }

        this.buttonPrev = this.querySelector(".js-prev");
        this.buttonNext = this.querySelector(".js-next");

        if (this.buttonNext && this.buttonPrev) {
          this.buttonPrev.addEventListener("click", (event) => {
            event.preventDefault();
            this.slideshow.transitionToPrev();
          });

          this.buttonNext.addEventListener("click", (event) => {
            event.preventDefault();
            this.slideshow.transitionToNext();
          });
        }
      }
    },
  );
}

function scrollIntoView({ element, container = window, behavior = "auto" }) {
  const elementRect = element.getBoundingClientRect();
  const containerRect = container.getBoundingClientRect();
  const elementTopRelativeToContainer = elementRect.top - containerRect.top + container.scrollTop;
  const elementHeight = elementRect.height;
  const containerHeight = containerRect.height;
  const centerOffset = Math.floor((containerHeight - elementHeight) / 2);
  container.scrollTo({
    top: elementTopRelativeToContainer - centerOffset,
    behavior: behavior,
  });
}
